# Cruzr voice semantic engine configuring access documents

##  Headrope
*  [Introduction to the way of configuration](#1)
  - [1.1 How to change the default voice system engine](#1-1)
  - [1.2 Introduction of configuration content](#1-2)
  - [1.3 The key data to modify for change voiceEngine](#1-3)
*  [Voice engine application access configuration](#2)
  - [2.1 How to realize developer's voice engine application](#2-1)
  - [2.2 Speech engine application interface docking](#2-2)
  - [2.3 Sdk in custom app](#2-3)

##  1 Introduction to the way of configuration
   The Cruzr voice semantic engine is designed in an open and flexible way, and the third party users can replace it voluntarily according to their requirements.
   
   At present, the default voice semantic engine is UBT, and the third party application can be mixed with custom engine configuration.

###  1.1 How to change the default voice system engine 
    Use Android's ContentProvider to configuring the engine for voice system , the Cruzr will scan the ContentProvider 
  
    where android:authorities= "com.ubtechinc.speech.cfg.provider".
    
    The developer only need override  the ContentProvider's call function, and return its config content.
    
    [Bundle call (String method, String Arg, Bundle extras) function]
  
	<provider
        android:authorities="com.ubtechinc.speech.cfg.provider"
        android:name="com.ubtechinc.speechservice.demo.ConfigProvider"
        android:exported="true" />

	@Override
    public Bundle call(String method, String arg, Bundle extras) {
        if (!TextUtils.isEmpty(method) && method.equals("readSpeechCfg")) {
            Bundle bl = new Bundle();
            bl.putString("config", mConfig);
            return bl;
        }
        return super.call(method, arg, extras);
    }
    
    the mConfig is json String using for change the default speechEngine , see the details below.

###  1.2 Introduction of configuration content
    default josn string config  
	{
       "voiceEngine" :{
            "speechEngine": "ubt",
            "nlpEngine": "ubt"
       },
    
       "voiceTts" :
         [
             {
                 "lan" : "zh-CN",
                 "voice": "ybxf1",
                 "speed": "50",
                 "tts":
                  [
                         {
                             "name": "ybxf1",
                             "sex": 1,
                             "adult": 1
                         },
                         {
                                "name": "xiaoyan",
                                "sex": 1,
                                "adult": 1
                           },
                         {
                             "name": "xiaofeng",
                             "sex": 0,
                             "adult": 1
                         }
                   ]
             },
             {
                  "lan" : "en-US",
                   "voice": "Samantha",
                   "speed": "50",
                   "tts": [
                            {
                              "name": "Samantha",
                                        "sex": 1,
                                        "adult": 1
                            }
                          ]
              }
         ]
    }

    The fields after parsing are shown below.

	public class SpeechCfgs implements IProguardKeeper {
        //voiceEngine
        public VoiceEngine voiceEngine;
        //voiceTts
        public List<VoiceTts> voiceTts;
    
        public static class VoiceEngine implements IProguardKeeper {
           // speech recognition engine key, according to this key matching voice engine, apply meta-data name = "speechEngine" value.
            public String speechEngine;
          // the semantic recognition engine key, according to the key matching semantic engine, applies meta-data name = "nlpEngine" value.
            public String nlpEngine;
        }
    
        public static class VoiceTts implements IProguardKeeper {
            //language
            public String lan;
            //default tts voice name
            public String voice;
            //default tts speed
            public int speed;
            public List<SpeechVoice> tts;
        }
    
        public static class SpeechVoice implements IProguardKeeper {
            // The name of the speaker
            public String name = "";
            //0: male 1: girl
            public int sex;
            // 0:not 1:yes
            public int adult;
        }
    }
    	
###  1.3 The key data to modify for change voiceEngine
    if developer wanna use self speechEngine, just change speechEngine value to a custom string
    like "developer_sppech", the "ubt" is default engine
    
    "voiceEngine" :{
        "speechEngine": "developer_sppech",
        "nlpEngine": "ubt"
   },


## 2 Voice engine application access configuration
    The voice engine includes speech recognition and TTS functions, if developer change the default engine,
    
    both shoud be completed

###  2.1 How to realize developer's voice engine application
    After the above configuration, you has change the speechEngine to "developer_sppech", so
    
    the developer's application also requires manifest configuration for voice system to find the new speechEngine.
    
    You just need a  manifest meta-data like below

*   <meta-data  android:name="speechEngine" android:value="developer_sppech" />  

     Among them, value must be the engine of speechEngine in appeal config, and this is the default ubt.
    
     Also the manifest need a service for ipc message, we will support a sdk for this.
        
*    IPC MessageService   （MessageService locate in sdk） 
		<service
		    android:name="com.ubtechinc.transportlib.messager.MessageService"
		    android:enabled="true"
		    android:exported="true">
		    <intent-filter>
		        <action android:name="com.ubtechinc.speechservice.demo.speech_service" />
		    </intent-filter>
		</service>
    MessageService's action name must be **applicationId+".speech_service"** 
    
    here the demo's "com.ubtechinc.speechservice.demo"

###  2.2 Speech engine application interface docking
 
*   >  **SpeechMessager.class**support IPC 
    > see demo code speechservice 
     
	mSpeechMessager = SpeechMessager.createMessager(new SpeechListener() {
    
            @Override
            public void build(String content) {
                //ignore
            }

            @Override
            public void startRecognize(boolean loop) {
                SpeechLog.i("startAsr");
                if (mSpeechAsr != null) {
                    mSpeechAsr.startAsr(AsrOption.createRecognizeOption(loop));
                }
            }

            @Override
            public void stopRecognize() {
                SpeechLog.i("stopAsr");
                if (mSpeechAsr != null) {
                    mSpeechAsr.stopAsr(false);
                }
            }

            @Override
            public void startSpeaking(String txt) {
                SpeechLog.i( "startSpeaking");
                if (mSpeechTTs != null) {
                    mSpeechTTs.startSpeaking(txt);
                }
            }

            @Override
            public void stopSpeaking() {
                SpeechLog.i( "stopSpeaking");
                if (mSpeechTTs != null) {
                    mSpeechTTs.stopSpeaking();
                }
            }

            @Override
            public void startListening() {
                SpeechLog.i( "startListening");
                if (mSpeechAsr != null) {
                    mSpeechAsr.startAsr(AsrOption.createListenOption(5, 500));
                }
            }

            @Override
            public void startListening(int timeOut, int eostime) {
                SpeechLog.i( "startListening");
                if (mSpeechAsr != null) {
                    mSpeechAsr.startAsr(AsrOption.createListenOption(timeOut, eostime));
                }
            }

            @Override
            public void stopListening() {
                SpeechLog.i( "stopListening");
                if (mSpeechAsr != null) {
                    mSpeechAsr.stopAsr(true);
                }
            }

            @Override
            public void setVoiceName(String name) {
                SpeechLog.i( "setVoiceName:"+name);
                if (mSpeechTTs != null) {
                    mSpeechTTs.setVoiceName(name);
                }
            }

            @Override
            public void setTtsSpeed(String speed) {
                SpeechLog.i( "setTtsSpeed:"+speed);
                if (mSpeechTTs != null) {
                    mSpeechTTs.setTtsSpeed(speed);
                }
            }

            @Override
            public void setTtsVolume(String volume) {
                SpeechLog.i( "setTtsVolume:"+volume);
                if (mSpeechTTs != null) {
                    mSpeechTTs.setTtsVolume(volume);
                }
            }
        });

###  2.3 Sdk in custom app
     Sdk trtansportlib in libs , it need a compile
     compile 'com.squareup:otto:1.3.8'
     
     Last , when install your engine app, reboot the android system of Cruzr
     
