package com.ubtechinc.speechservice.demo.utils;

import android.util.Log;

/**
 * @author andy.liu
 * @ClassName
 * @date 2018/3/6
 * @Description
 * @modifier
 * @modify_time
 */
public class SpeechLog {
    private static String TAG = "paul_ubt_speech_test";

    public static void e(String msg){
        Log.e(TAG,msg);
    }

    public static void e(String msg,Object... args){
        Log.e(TAG,String.format(msg,args));
    }

    public static void i(String msg){
        Log.i(TAG,msg);
    }

    public static void i(String msg,Object... args){
        Log.i(TAG,String.format(msg,args));
    }

    public static void t(String tag, String msg, Object... args) {
        Log.e(tag, String.format(msg, args));
    }

    public static void t(String tag, String msg) {
        Log.i(tag, msg);
    }

}
