package com.ubtechinc.speechservice.demo.speech.tts;

/**
 * @author andy.liu
 * @ClassName
 * @date 2018/3/14
 * @Description
 * @modifier
 * @modify_time
 */
public interface ITtsCallback {
    void onTtsStart();

    void onTtsStop();
}
