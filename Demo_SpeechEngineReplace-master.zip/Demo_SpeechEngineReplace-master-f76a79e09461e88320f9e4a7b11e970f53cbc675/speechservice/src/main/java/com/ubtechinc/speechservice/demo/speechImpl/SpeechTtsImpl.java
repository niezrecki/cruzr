package com.ubtechinc.speechservice.demo.speechImpl;


import android.os.Handler;
import android.os.Looper;

import com.ubtechinc.speechservice.demo.speech.tts.AbsSpeechTts;
import com.ubtechinc.speechservice.demo.speech.tts.ITtsCallback;
import com.ubtechinc.speechservice.demo.utils.SpeechLog;
import com.ubtechinc.transportlib.common.UConstant;
import com.ubtechinc.transportlib.messager.EventMessage;
import com.ubtechinc.transportlib.messager.IMessageSender;

/**
 * @author andy.liu
 * @ClassName
 * @date 2018/3/6
 * @Description tts impl
 * @modifier
 * @modify_time
 */
public class SpeechTtsImpl extends AbsSpeechTts implements ITtsCallback {

    private Handler mTestHandler = new Handler(Looper.getMainLooper());

    public SpeechTtsImpl(IMessageSender sender) {
        super(sender);
    }

    @Override
    public void init() {
    }

    @Override
    public void setVoiceName(String name) {
        SpeechLog.i("setVoiceName");
    }

    @Override
    public void setTtsVolume(String volume) {
        SpeechLog.i("setTtsVolume");
    }

    @Override
    public void setTtsSpeed(String speed) {
        SpeechLog.i("setTtsSpeed");
    }

    @Override
    public void startSpeaking(String txt, ITtsCallback callback) {
        SpeechLog.i("startSpeaking");
        startSpeaking(txt);
    }

    @Override
    public void startSpeaking(String txt) {
        SpeechLog.i("startSpeaking:" + txt);

        mTestHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                onTtsStop();
            }
        }, 2000);
    }

    @Override
    public void stopSpeaking() {
        SpeechLog.i("stopSpeaking");
    }

    @Override
    public boolean isSpeaking() {
        SpeechLog.i("isSpeaking");

        return false;
    }

    @Override
    public void destory() {

    }


    @Override
    public void onTtsStart() {
        //current not use
        mSpeechSender.sendMessage(EventMessage.createSubMessage(UConstant.EVENT_CALLBACK_TTS, UConstant.SpeechStatus.EVENT_START_TTS));
    }

    @Override
    public void onTtsStop() {
        mSpeechSender.sendMessage(EventMessage.createSubMessage(UConstant.EVENT_CALLBACK_TTS, UConstant.SpeechStatus.EVENT_STOP_TTS));
    }
}
