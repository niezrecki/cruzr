package com.ubtechinc.speechservice.demo.speechImpl;

import android.os.Handler;
import android.os.Looper;

import com.ubtechinc.speechservice.demo.speech.asr.AbsAsr;
import com.ubtechinc.speechservice.demo.speech.asr.AsrOption;
import com.ubtechinc.speechservice.demo.speech.asr.IAsrCallback;
import com.ubtechinc.speechservice.demo.utils.RecognizeSenderHelper;
import com.ubtechinc.speechservice.demo.utils.SpeechLog;
import com.ubtechinc.transportlib.common.UConstant;
import com.ubtechinc.transportlib.messager.IMessageSender;
import com.ubtechinc.transportlib.speech.OfflineSlot;

/**
 * @author andy.liu
 * @ClassName
 * @date 2018/3/6
 * @Description 语音引擎听写包装类，分离回调逻辑
 * @modifier
 * @modify_time
 */

public class SpeechAsrImpl extends AbsAsr implements IAsrCallback {
    private RecognizeSenderHelper mSpeechSenderHelper;

    private Handler mTestHandler = new Handler(Looper.getMainLooper());

    public SpeechAsrImpl(IMessageSender sender) {
        mSpeechSenderHelper = new RecognizeSenderHelper(sender);
    }


    @Override
    public void buildGrammar(String content) {
        //ignore
    }

    /**
     * should not call this function, call startAsr(AsrOption option)
     *
     * @param callback
     * @param option
     */
    @Override
    public void startAsr(IAsrCallback callback, AsrOption option) {
        SpeechLog.i("asr startAsr");
    }

    @Override
    public void startAsr(AsrOption option) {
        SpeechLog.i("asr startAsr");

        //1 begin recoginze
        mTestHandler.post(new Runnable() {
            @Override
            public void run() {
                onBeginOfSpeech();
            }
        });

        //2 callback volume
        mTestHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                onVolumeChanged(5);
            }
        }, 150);

        mTestHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                onVolumeChanged(8);
            }
        }, 250);

        //3 callback end of recoginze
        mTestHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                onEndOfSpeech();
            }
        }, 1500);

        //4 call back result
        mTestHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                onResult("what's the whether?", true);
            }
        }, 2500);
    }

    @Override
    public void stopAsr(boolean justListen) {
        SpeechLog.i("asr startAsr");
    }

    @Override
    public void init() {

    }

    @Override
    public void destory() {
    }


    @Override
    public void onVolumeChanged(int volume) {
        mSpeechSenderHelper.sendVolumeMessage(UConstant.EVENT_CALLBACK_RECOGNIZE, volume);
    }

    @Override
    public void onBeginOfSpeech() {
        SpeechLog.i("asr onBeginOfSpeech");
        mSpeechSenderHelper.sendBeginMessage(UConstant.EVENT_CALLBACK_RECOGNIZE);
    }

    @Override
    public void onEndOfSpeech() {
        SpeechLog.i("asr onEndOfSpeech");
        mSpeechSenderHelper.sendEndMessage(UConstant.EVENT_CALLBACK_RECOGNIZE);
    }


    @Override
    public void onResult(String result, boolean end) {
        SpeechLog.i("AsrResult:" + result + ", end :" + end);
        mSpeechSenderHelper.sendAsrMessage(result, end);
    }

    @Override
    public void onResult(OfflineSlot slot, boolean end) {
        //ignore
    }

    @Override
    public void onError(int code) {
        SpeechLog.i("asr onError: " + code);
        mSpeechSenderHelper.sendErrorMessage(UConstant.EVENT_CALLBACK_RECOGNIZE, code);
    }
}


