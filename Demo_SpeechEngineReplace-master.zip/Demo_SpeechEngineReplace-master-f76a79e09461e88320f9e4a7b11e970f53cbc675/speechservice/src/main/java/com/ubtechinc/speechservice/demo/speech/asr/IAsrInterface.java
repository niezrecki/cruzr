package com.ubtechinc.speechservice.demo.speech.asr;

/**
 * @author andy.liu
 * @ClassName
 * @date 2018/3/22
 * @Description 语音识别对外功能接口
 * @modifier
 * @modify_time
 */
public interface IAsrInterface {

    void buildGrammar(String content);

    void startAsr(IAsrCallback callback, AsrOption option);

    void stopAsr(boolean justListen);

    void init();

    void destory();

    void setParam(String key, String value);
}
