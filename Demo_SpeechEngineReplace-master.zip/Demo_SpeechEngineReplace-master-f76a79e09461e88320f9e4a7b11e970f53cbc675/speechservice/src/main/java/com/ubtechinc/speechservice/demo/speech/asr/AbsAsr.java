package com.ubtechinc.speechservice.demo.speech.asr;

/**
 * @author andy.liu
 * @ClassName
 * @date 2018/3/6
 * @Description
 * @modifier
 * @modify_time
 */
public abstract class AbsAsr implements IAsrInterface {
    public abstract void startAsr(AsrOption option);

    public void setParam(String key, String value) {

    }
}
