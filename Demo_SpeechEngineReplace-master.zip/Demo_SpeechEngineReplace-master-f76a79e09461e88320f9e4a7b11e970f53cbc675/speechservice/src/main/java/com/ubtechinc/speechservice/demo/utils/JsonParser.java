/*
 *
 *  *
 *  * Copyright (c) 2008-2016 UBT Corporation.  All rights reserved.  Redistribution,
 *  *  modification, and use in source and binary forms are not permitted unless otherwise authorized by UBT.
 *  *
 *
 */

package com.ubtechinc.speechservice.demo.utils;

import com.ubtechinc.transportlib.speech.OfflineSlot;

/**
 * @author paul.zhang@ubtrobot.com
 * @date 2017/2/28
 * @Description 解析工具类
 * @modifier
 * @modify_time
 */

public class JsonParser {

	public static OfflineSlot getSlotFromAsrResult(String json) {
		OfflineSlot slot = null;
		//TODO 生成本地指令
		return slot;
	}

	public static String getCmdOnline(String jsonStr) {
		String text = jsonStr;
		//todo
		return text;
	}

}
