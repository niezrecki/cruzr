package com.ubtechinc.speechservice.demo.speech.tts;

import com.ubtechinc.transportlib.messager.IMessageSender;

/**
 * @author andy.liu
 * @ClassName
 * @date 2018/3/6
 * @Description
 * @modifier
 * @modify_time
 */
public abstract class AbsSpeechTts implements ITtsInterface {
    protected IMessageSender mSpeechSender;

    public AbsSpeechTts(IMessageSender sender) {
        mSpeechSender = sender;
    }

    public abstract void startSpeaking(String txt);

}
