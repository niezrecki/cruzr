package com.ubtechinc.speechservice.demo;

import android.app.Application;
import android.content.Context;

import com.ubtechinc.speechservice.demo.speech.asr.AbsAsr;
import com.ubtechinc.speechservice.demo.speech.asr.AsrOption;
import com.ubtechinc.speechservice.demo.speech.tts.AbsSpeechTts;
import com.ubtechinc.speechservice.demo.speechImpl.SpeechAsrImpl;
import com.ubtechinc.speechservice.demo.speechImpl.SpeechTtsImpl;
import com.ubtechinc.speechservice.demo.utils.SpeechLog;
import com.ubtechinc.transportlib.speech.SpeechListener;
import com.ubtechinc.transportlib.speech.SpeechMessager;


public class App extends Application {
    public SpeechMessager mSpeechMessager;
    public AbsAsr mSpeechAsr;
    public AbsSpeechTts mSpeechTTs;

    private static Context sAppContext;

    @Override
    public void onCreate() {
        super.onCreate();
        sAppContext = this;
        init();
    }

    private void init() {
        initService();
        mSpeechAsr = new SpeechAsrImpl(mSpeechMessager);
        mSpeechTTs = new SpeechTtsImpl(mSpeechMessager);
    }

    private void initService() {
        mSpeechMessager = SpeechMessager.createMessager(new SpeechListener() {

            @Override
            public void build(String content) {
                //ignore
            }

            @Override
            public void startRecognize(boolean loop) {
                SpeechLog.i("startAsr");
                if (mSpeechAsr != null) {
                    mSpeechAsr.startAsr(AsrOption.createRecognizeOption(loop));
                }
            }

            @Override
            public void stopRecognize() {
                SpeechLog.i("stopAsr");
                if (mSpeechAsr != null) {
                    mSpeechAsr.stopAsr(false);
                }
            }

            @Override
            public void startSpeaking(String txt) {
                SpeechLog.i("startSpeaking");
                if (mSpeechTTs != null) {
                    mSpeechTTs.startSpeaking(txt);
                }
            }

            @Override
            public void stopSpeaking() {
                SpeechLog.i("stopSpeaking");
                if (mSpeechTTs != null) {
                    mSpeechTTs.stopSpeaking();
                }
            }

            /**
             * listen means the voice system will not ask for nlp ,just send result to app
             * like voice input
             */
            @Override
            public void startListening() {
                SpeechLog.i("startListening");
                if (mSpeechAsr != null) {
                    mSpeechAsr.startAsr(AsrOption.createListenOption(5));
                }
            }

            //
            @Override
            public void startListening(int timeOut, int eostime) {
                SpeechLog.i("startListening");
                if (mSpeechAsr != null) {
                    mSpeechAsr.startAsr(AsrOption.createListenOption(timeOut));
                }
            }

            /**
             * just stop listen , engine can ignore this
             */
            @Override
            public void stopListening() {
                SpeechLog.i("stopListening");
                if (mSpeechAsr != null) {
                    mSpeechAsr.stopAsr(true);
                }
            }

            @Override
            public void setVoiceName(String name) {
                SpeechLog.i("setVoiceName:" + name);
                if (mSpeechTTs != null) {
                    mSpeechTTs.setVoiceName(name);
                }
            }

            @Override
            public void setTtsSpeed(String speed) {
                SpeechLog.i("setTtsSpeed:" + speed);
                if (mSpeechTTs != null) {
                    mSpeechTTs.setTtsSpeed(speed);
                }
            }

            @Override
            public void setTtsVolume(String volume) {
                SpeechLog.i("setTtsVolume:" + volume);
                if (mSpeechTTs != null) {
                    mSpeechTTs.setTtsVolume(volume);
                }
            }
        });
    }

    public static Context getAppContext() {
        return sAppContext;
    }
}
