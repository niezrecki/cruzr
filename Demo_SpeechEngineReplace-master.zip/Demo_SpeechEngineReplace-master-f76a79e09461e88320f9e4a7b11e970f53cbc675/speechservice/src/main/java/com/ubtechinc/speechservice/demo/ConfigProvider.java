package com.ubtechinc.speechservice.demo;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;

/**
 * @author andy.liu
 * @ClassName
 * @date 2018/4/20
 * @Description
 * @modifier
 * @modify_time
 */
public class ConfigProvider extends ContentProvider {
    @Override
    public boolean onCreate() {
        return false;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        return null;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }

    private final String mConfig = "{\n" +
            "            \"voiceEngine\" :{\n" +
            "        \"speechEngine\": \"ubt_test\",\n" +
            "                \"nlpEngine\": \"ubt_test\"\n" +
            "    },\n" +
            "\n" +
            "            \"voiceTts\" :\n" +
            "            [\n" +
            "    {\n" +
            "        \"lan\" : \"zh-CN\",\n" +
            "            \"voice\": \"ybxf1\",\n" +
            "            \"speed\": \"50\",\n" +
            "            \"tts\":\n" +
            "              [\n" +
            "        {\n" +
            "            \"name\": \"ybxf1\",\n" +
            "                \"sex\": 1,\n" +
            "                \"adult\": 1\n" +
            "        },\n" +
            "        {\n" +
            "            \"name\": \"xiaoyan\",\n" +
            "                \"sex\": 1,\n" +
            "                \"adult\": 1\n" +
            "        },\n" +
            "        {\n" +
            "            \"name\": \"xiaofeng\",\n" +
            "                \"sex\": 0,\n" +
            "                \"adult\": 1\n" +
            "        }\n" +
            "               ]\n" +
            "    },\n" +
            "    {\n" +
            "        \"lan\" : \"en-US\",\n" +
            "            \"voice\": \"Samantha\",\n" +
            "            \"speed\": \"50\",\n" +
            "            \"tts\": [\n" +
            "        {\n" +
            "            \"name\": \"Samantha\",\n" +
            "                \"sex\": 1,\n" +
            "                \"adult\": 1\n" +
            "        }\n" +
            "                      ]\n" +
            "    },\n" +
            "    {\n" +
            "        \"lan\" : \"zh-TW\",\n" +
            "            \"voice\": \"ybxf1\",\n" +
            "            \"speed\": \"50\",\n" +
            "            \"tts\": [\n" +
            "        {\n" +
            "            \"name\": \"ybxf1\",\n" +
            "                \"sex\": 1,\n" +
            "                \"adult\": 1\n" +
            "        },\n" +
            "        {\n" +
            "            \"name\": \"xiaoyan\",\n" +
            "                \"sex\": 1,\n" +
            "                \"adult\": 1\n" +
            "        },\n" +
            "        {\n" +
            "            \"name\": \"xiaofeng\",\n" +
            "                \"sex\": 0,\n" +
            "                \"adult\": 1\n" +
            "        }\n" +
            "                     ]\n" +
            "    }\n" +
            "     ]\n" +
            "\n" +
            "}";

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        if (!TextUtils.isEmpty(method) && method.equals("readSpeechCfg")) {
            Bundle bl = new Bundle();
            bl.putString("config", mConfig);
            return bl;
        }
        return super.call(method, arg, extras);
    }
}
