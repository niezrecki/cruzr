package com.ubtechinc.speechservice.demo.speech.asr;

/**
 * @author andy.liu
 * @ClassName
 * @date 2018/5/23
 * @Description
 * @modifier
 * @modify_time
 */
public class AsrOption {
    private final static int TIME_OUT = 10;
    public volatile boolean loop; //once shot and continue recogining
    public volatile boolean justListen; //this flag means just for voice input ,but engine can ignore
    public int timeout; // enable for justListen, engine also can ignore

    public static AsrOption createRecognizeOption(boolean loop) {
        AsrOption asrOption = new AsrOption();
        asrOption.loop = loop;
        asrOption.justListen = false;
        asrOption.timeout = TIME_OUT;
        return asrOption;
    }

    public static AsrOption createListenOption(int timeout) {
        AsrOption asrOption = new AsrOption();
        asrOption.justListen = true;
        asrOption.timeout = timeout;
        return asrOption;
    }
}
