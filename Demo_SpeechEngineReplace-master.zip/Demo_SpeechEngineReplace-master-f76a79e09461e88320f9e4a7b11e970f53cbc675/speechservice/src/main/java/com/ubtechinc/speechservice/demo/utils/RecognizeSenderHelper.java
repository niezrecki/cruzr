package com.ubtechinc.speechservice.demo.utils;


import com.ubtechinc.transportlib.common.UConstant;
import com.ubtechinc.transportlib.messager.EventMessage;
import com.ubtechinc.transportlib.messager.IMessageSender;

import org.jetbrains.annotations.NotNull;

/**
 * @author andy.liu
 * @Description: 语音事件预处理
 * @date 2018/3/8 15:07
 * @copyright UBTECH
 */
public class RecognizeSenderHelper {

    private IMessageSender mMessageSender;

    public RecognizeSenderHelper(@NotNull IMessageSender sender) {
        mMessageSender = sender;
    }

    public void sendVolumeMessage(int type, int volume) {
        mMessageSender.sendMessage(EventMessage.createSubValueMessage(type, UConstant.SpeechStatus.EVENT_VOLUME_CHANGE, volume));
    }

    public void sendBeginMessage(int type) {
        mMessageSender.sendMessage(EventMessage.createSubMessage(type, UConstant.SpeechStatus.EVENT_BEGIN_SPEECH));
    }

    public void sendEndMessage(int type) {
        mMessageSender.sendMessage(EventMessage.createSubMessage(type, UConstant.SpeechStatus.EVENT_END_SPEECH));
    }

    public void sendErrorMessage(int type, int error) {
        mMessageSender.sendMessage(EventMessage.createSubValueMessage(type, UConstant.SpeechStatus.EVENT_ERROR_SPEECH, error));
    }

    public void sendAsrMessage(final String result, final boolean end) {
        mMessageSender.sendMessage(EventMessage.createSubValueMessage(UConstant.EVENT_CALLBACK_RECOGNIZE, UConstant.SpeechStatus.EVENT_RESULT_SPEECH, result, (end ? 1 : 0), UConstant.SpeechStatus.COMMAND_ONLINE));
    }

}
