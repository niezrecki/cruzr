package com.ubtechinc.speechservice.demo.speech.tts;

/**
 * @author andy.liu
 * @ClassName
 * @date 2018/3/14
 * @Description tts对外功能接口
 * @modifier
 * @modify_time
 */
public interface ITtsInterface {

    void init();

    void setVoiceName(String name);

    void setTtsVolume(String volume);

    void setTtsSpeed(String speed);

    void startSpeaking(String txt, ITtsCallback callback);

    void stopSpeaking();

    boolean isSpeaking();

    void destory();
}
