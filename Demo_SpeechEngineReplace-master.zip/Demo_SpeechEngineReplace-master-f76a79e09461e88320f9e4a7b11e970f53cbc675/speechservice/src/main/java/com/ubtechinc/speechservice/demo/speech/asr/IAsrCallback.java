package com.ubtechinc.speechservice.demo.speech.asr;

import com.ubtechinc.transportlib.speech.OfflineSlot;

/**
 * @author andy.liu
 * @ClassName
 * @date 2018/3/22
 * @Description
 * @modifier
 * @modify_time
 */
public interface IAsrCallback {
    void onBeginOfSpeech();

    void onEndOfSpeech();

    void onVolumeChanged(int volume);

    void onResult(String result, boolean end);

    void onResult(OfflineSlot slot, boolean end);

    void onError(int code);
}
