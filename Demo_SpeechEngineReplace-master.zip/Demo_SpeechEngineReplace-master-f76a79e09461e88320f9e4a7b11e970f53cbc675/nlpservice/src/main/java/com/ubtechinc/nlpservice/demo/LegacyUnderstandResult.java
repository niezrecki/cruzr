package com.ubtechinc.nlpservice.demo;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;

public class LegacyUnderstandResult extends UnderstandResult {

    private LegacyData legacyData;

    public LegacyUnderstandResult(Builder builder) {
        super(builder);
    }

    public LegacyUnderstandResult(Parcel in) {
        super(in);
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeParcelable(legacyData, flags);
    }

    @SuppressWarnings("unchecked")
    public void readFromParcel(Parcel in) {
        super.readFromParcel(in);
        legacyData = in.readParcelable(LegacyData.class.getClassLoader());
    }

    public LegacyData getLegacyData() {
        return legacyData;
    }

    public static class Builder extends UnderstandResult.Builder {

        private LegacyData legacyData = LegacyData.NULL;

        public Builder() {
        }

        public Builder(LegacyUnderstandResult result) {
            this.legacyData = result.legacyData;
            this.setInputText(result.getInputText());
            this.setActionIncomplete(result.isActionIncomplete());
            List<Context> copy = new ArrayList<>(result.getContexts());
            this.setContexts(copy);
            this.setFulfillment(result.getFulfillment());
            this.setIntent(result.getIntent());
            this.setLanguage(result.getLanguage());
            this.setSessionId(result.getSessionId());
            this.setSource(result.getSource());
        }

        public void setLegacyData(LegacyData legacyData) {
            this.legacyData = legacyData;
        }

        @Override
        public String getInputText() {
            return super.getInputText();
        }

        @Override
        public LegacyUnderstandResult build() {
            LegacyUnderstandResult legacyUnderstandResult = new LegacyUnderstandResult(this);
            legacyUnderstandResult.legacyData = legacyData;
            return legacyUnderstandResult;
        }
    }

    public Builder toBuilder() {
        return new Builder(this);
    }

    public static class LegacyData implements Parcelable {

        public static final LegacyData NULL = new Builder().build();
        public String uuid = "";
        public int appId = 1002;
        //自定义场景问题指定id
        public int id;
        //当前问题
        public String request = "";
        //自然语言处理意图
        public String intent = "";
        //问题答案
        public String reply = "";
        //自然语言处理后台全部内容
        public String meta = "";
        //后台扩展格式
        public String data;
        //唤醒类型
        public int wakeup;
        //指令模式 0：离线指令 1：在线指令
        public int command;

        private LegacyData() {
        }

        public LegacyData(Parcel in) {
            readFromParcel(in);
        }

        public String getUuid() {
            return uuid;
        }

        public int getAppId() {
            return appId;
        }

        public int getId() {
            return id;
        }

        public String getRequest() {
            return request;
        }

        public String getIntent() {
            return intent;
        }

        public String getReply() {
            return reply;
        }

        public String getMeta() {
            return meta;
        }

        public String getData() {
            return data;
        }

        public int getWakeup() {
            return wakeup;
        }

        public int getCommand() {
            return command;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(uuid);
            dest.writeInt(appId);
            dest.writeInt(id);
            dest.writeString(request);
            dest.writeString(intent);
            dest.writeString(reply);
            dest.writeString(meta);
            dest.writeString(data);
            dest.writeInt(wakeup);
            dest.writeInt(command);

        }

        @SuppressWarnings("unchecked")
        private void readFromParcel(Parcel in) {
            uuid = in.readString();
            appId = in.readInt();
            id = in.readInt();
            request = in.readString();
            intent = in.readString();
            reply = in.readString();
            meta = in.readString();
            data = in.readString();
            wakeup = in.readInt();
            command = in.readInt();
        }

        public static final Creator<LegacyData> CREATOR = new Creator<LegacyData>() {
            @Override
            public LegacyData createFromParcel(Parcel source) {
                return new LegacyData(source);
            }

            @Override
            public LegacyData[] newArray(int size) {
                return new LegacyData[size];
            }
        };

        public static class Builder {
            public String uuid = "";
            public int appId = 1002;
            //自定义场景问题指定id
            public int id;
            //当前问题
            public String request = "";
            //自然语言处理意图
            public String intent = "";
            //问题答案
            public String reply = "";
            //自然语言处理后台全部内容
            public String meta = "";
            //后台扩展格式
            public String data = "";
            //唤醒类型
            public int wakeup;
            //指令模式 0：离线指令 1：在线指令
            public int command;

            public Builder() {
            }

            public Builder(LegacyData data) {
                this.uuid = data.uuid;
                this.appId = data.appId;
                this.id = data.id;
                this.request = data.request;
                this.intent = data.intent;
                this.reply = data.reply;
                this.meta = data.meta;
                this.data = data.data;
                this.wakeup = data.wakeup;
                this.command = data.command;
            }

            public Builder setUuid(String uuid) {
                this.uuid = uuid;
                return this;
            }

            public Builder setAppId(int appId) {
                this.appId = appId;
                return this;
            }

            public Builder setId(int id) {
                this.id = id;
                return this;
            }

            public Builder setRequest(String request) {
                this.request = request;
                return this;
            }

            public Builder setIntent(String intent) {
                this.intent = intent;
                return this;
            }

            public Builder setReply(String reply) {
                this.reply = reply;
                return this;
            }

            public Builder setMeta(String meta) {
                this.meta = meta;
                return this;
            }

            public Builder setData(String data) {
                this.data = data;
                return this;
            }

            public Builder setWakeup(int wakeup) {
                this.wakeup = wakeup;
                return this;
            }

            public Builder setCommand(int command) {
                this.command = command;
                return this;
            }

            public LegacyData build() {
                LegacyData legacyData = new LegacyData();
                legacyData.uuid = uuid;
                legacyData.appId = appId;
                legacyData.id = id;
                legacyData.request = request;
                legacyData.intent = intent;
                legacyData.reply = reply;
                legacyData.meta = meta;
                legacyData.data = data;
                legacyData.wakeup = wakeup;
                legacyData.command = command;
                return legacyData;
            }
        }

        @Override
        public String toString() {
            return "LegacyData{" +
                    "uuid='" + uuid + '\'' +
                    ", appId=" + appId +
                    ", id=" + id +
                    ", request='" + request + '\'' +
                    ", intent='" + intent + '\'' +
                    ", reply='" + reply + '\'' +
                    ", meta='" + meta + '\'' +
                    ", data=" + data +
                    ", wakeup=" + wakeup +
                    ", command=" + command +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "LegacyUnderstandResult{" +
                "legacyData=" + legacyData + super.toString() +
                '}';
    }
}
