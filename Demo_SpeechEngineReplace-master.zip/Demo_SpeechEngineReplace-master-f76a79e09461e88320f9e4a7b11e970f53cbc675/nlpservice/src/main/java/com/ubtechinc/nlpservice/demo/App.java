package com.ubtechinc.nlpservice.demo;

import android.app.Application;

import com.google.gson.Gson;
import com.ubtechinc.transportlib.common.UConstant;
import com.ubtechinc.transportlib.messager.EventMessage;
import com.ubtechinc.transportlib.messager.IMessageSender;
import com.ubtechinc.transportlib.nlp.NlpListener;
import com.ubtechinc.transportlib.nlp.NlpMessager;

/**
 * @author paul.zhang@ubtrobot.com
 * @date 2018/2/2
 * @Description 第三方NLP语义处理
 * @modifier
 * @modify_time
 */

public class App extends Application {
    protected IMessageSender mIMessageSender;

    @Override
    public void onCreate() {
        super.onCreate();
        init();
    }

    private void init() {
        //初始化主服务接口
        initService();
    }


    private void initService() {
        mIMessageSender = NlpMessager.createMessager(new NlpListener() {
            @Override
            public void onNlp(String request, String uuid) {
                handleNlp(request, uuid);
            }
        });
    }

    private String testJsonResult(String request) {
        UnderstandResult.Fulfillment.Builder fullBuilder = new UnderstandResult.Fulfillment.Builder();
        fullBuilder.setSpeech("shen zhen has a good day");

        LegacyUnderstandResult.Builder builder = new LegacyUnderstandResult.Builder();
        LegacyUnderstandResult reply =
                (LegacyUnderstandResult) builder.setInputText(request)
                        .setFulfillment(fullBuilder.build())
                        .build();


        return new Gson().toJson(reply);
    }

    private void handleNlp(String request, String uuid) {
        sendMessage(UConstant.EVENT_CALLBACK_NLP, testJsonResult(request), uuid);
    }

    public void sendMessage(int event, String content, String uuid) {
        if (mIMessageSender != null) {
            mIMessageSender.sendMessage(EventMessage.createMessage(event, content, uuid));
        }
    }
}
